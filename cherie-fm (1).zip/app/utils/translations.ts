type TranslationKey = string
type LanguageCode = "uk" | "en" | "fr"

const translations: Record<TranslationKey, Record<LanguageCode, string>> = {
  news: {
    uk: "Новини",
    en: "News",
    fr: "Actualités",
  },
  more_news: {
    uk: "Більше новин",
    en: "More news",
    fr: "Plus d'actualités",
  },
  site_map: {
    uk: "Мапа сайту",
    en: "Site Map",
    fr: "Plan du site",
  },
  contact: {
    uk: "Контакти",
    en: "Contact",
    fr: "Contact",
  },
  about: {
    uk: "Про радіо",
    en: "About",
    fr: "À propos",
  },
  presenters: {
    uk: "Ведучі",
    en: "Presenters",
    fr: "Présentateurs",
  },
  advertising: {
    uk: "Реклама",
    en: "Advertising",
    fr: "Publicité",
  },
  legal: {
    uk: "Правова інформація",
    en: "Legal",
    fr: "Mentions légales",
  },
  support: {
    uk: "Підтримати",
    en: "Support",
    fr: "Soutenir",
  },
  // Add more translations as needed
}

export function t(key: TranslationKey, language: LanguageCode): string {
  return translations[key]?.[language] || key
}

