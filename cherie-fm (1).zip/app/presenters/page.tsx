import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

const presenters = [
  {
    name: "Анна Ковальчук",
    program: "Ранковий Драйв",
    bio: "Анна - досвідчена радіоведуча з 10-річним стажем. Її енергійний голос та позитивний настрій допомагають слухачам прокинутися та зарядитися енергією на весь день.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    name: "Олег Петренко",
    program: "Музичний Мікс",
    bio: "Олег - справжній меломан та експерт у світі музики. Його програма 'Музичний мікс' знайомить слухачів з найкращими хітами та новинками української та світової музики.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    name: "Марія Шевченко",
    program: "Вечірній Настрій",
    bio: "Марія має унікальний талант створювати затишну атмосферу в ефірі. Її програма 'Вечірній Настрій' допомагає слухачам розслабитися після робочого дня та насолодитися хорошою музикою.",
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function PresentersPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Ведучі</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {presenters.map((presenter, index) => (
          <Card key={index}>
            <CardHeader>
              <Image
                src={presenter.image || "/placeholder.svg"}
                alt={presenter.name}
                width={200}
                height={200}
                className="w-full h-48 object-cover mb-4 rounded"
              />
              <CardTitle>{presenter.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-2">Програма: {presenter.program}</p>
              <p>{presenter.bio}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

