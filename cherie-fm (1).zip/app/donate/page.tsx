import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function DonatePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Підтримати Шері ФМ</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Чому варто підтримати Шері ФМ?</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside space-y-2">
              <li>Ми створюємо унікальний контент та підтримуємо українську музику</li>
              <li>Ми надаємо платформу для обговорення важливих суспільних тем</li>
              <li>Ми інвестуємо в нові технології для покращення якості мовлення</li>
              <li>Ми підтримуємо молодих талановитих музикантів та ведучих</li>
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Як ви можете підтримати нас?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h3 className="font-semibold mb-2">Одноразовий внесок</h3>
              <p className="mb-2">Зробіть одноразовий внесок будь-якого розміру, щоб підтримати нашу роботу.</p>
              <Button className="bg-pink-600 hover:bg-pink-700 text-white">Зробити внесок</Button>
            </div>
            <div>
              <h3 className="font-semibold mb-2">Регулярна підтримка</h3>
              <p className="mb-2">Станьте нашим постійним спонсором з щомісячним внеском.</p>
              <Button variant="outline" className="border-pink-600 text-pink-600 hover:bg-pink-600 hover:text-white">
                Стати спонсором
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      <p className="mt-8 text-center">
        Дякуємо за вашу підтримку! Разом ми зможемо продовжувати створювати якісний радіоконтент для наших слухачів.
      </p>
    </div>
  )
}

