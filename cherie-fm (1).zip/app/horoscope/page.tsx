import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export default async function HoroscopePage() {
  const horoscopes = await prisma.horoscope.findMany({
    where: {
      date: new Date(),
    },
  })

  const currentDate = new Date().toLocaleDateString("uk-UA", { day: "numeric", month: "long", year: "numeric" })

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8 text-[#800020]">Гороскоп на {currentDate}</h1>
      <div className="space-y-6">
        {horoscopes.map((horoscope) => (
          <Card key={horoscope.id}>
            <CardHeader className="p-4">
              <CardTitle className="flex items-center">
                <span>{horoscope.sign}</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              <p className="text-lg">{horoscope.prediction}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

