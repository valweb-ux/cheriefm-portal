import { useLanguage } from "../components/LanguageProvider"

export default function LegalPage() {
  const { language } = useLanguage()

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Правова інформація</h1>
      <div className="space-y-6">
        <section>
          <h2 className="text-2xl font-semibold mb-4">Умови використання</h2>
          <p>
            Використовуючи веб-сайт Шері ФМ, ви погоджуєтесь дотримуватися наших умов використання. Будь ласка, уважно
            ознайомтеся з ними перед використанням нашого сайту або послуг.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-4">Політика конфіденційності</h2>
          <p>
            Ми поважаємо вашу приватність і зобов'язуємося захищати ваші особисті дані. Наша політика конфіденційності
            описує, як ми збираємо, використовуємо та захищаємо вашу інформацію.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-4">Авторські права</h2>
          <p>
            Весь контент на веб-сайті cheriefm.online, включаючи тексти, зображення, аудіо та відео матеріали, захищений
            авторським правом і належить Шері ФМ Україна або нашим партнерам.
          </p>
        </section>
        <section>
          <h2 className="text-2xl font-semibold mb-4">Відмова від відповідальності</h2>
          <p>
            Шері ФМ не несе відповідальності за будь-які прямі, непрямі, випадкові або наслідкові збитки, пов'язані з
            використанням нашого веб-сайту або послуг.
          </p>
        </section>
        <p>
          Якщо у вас виникли питання щодо нашої правової інформації, будь ласка, зв'яжіться з нами за адресою:
          legal@cherifm.ua
        </p>
      </div>
    </div>
  )
}

