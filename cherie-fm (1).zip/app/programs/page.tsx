import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

const programs = [
  {
    title: "Ранковий Драйв",
    host: "Анна Ковальчук",
    time: "Пн-Пт, 7:00 - 10:00",
    description: "Прокиньтеся з позитивним настроєм та енергією на весь день!",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    title: "Музичний Мікс",
    host: "Олег Петренко",
    time: "Пн-Пт, 12:00 - 15:00",
    description: "Найкращі хіти та нові треки в одному шоу.",
    image: "/placeholder.svg?height=200&width=200",
  },
  {
    title: "Вечірній Настрій",
    host: "Марія Шевченко",
    time: "Пн-Пт, 18:00 - 21:00",
    description: "Розслабтеся після робочого дня з приємною музикою та цікавими розмовами.",
    image: "/placeholder.svg?height=200&width=200",
  },
]

export default function ProgramsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Програми</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {programs.map((program, index) => (
          <Card key={index}>
            <CardHeader>
              <Image
                src={program.image || "/placeholder.svg"}
                alt={program.title}
                width={200}
                height={200}
                className="w-full h-48 object-cover mb-4 rounded"
              />
              <CardTitle>{program.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-2">Ведучий: {program.host}</p>
              <p className="text-gray-600 mb-2">{program.time}</p>
              <p>{program.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

