import Link from "next/link"
import NewsCarousel from "./components/NewsCarousel"
import PopularShows from "./components/PopularShows"

export default function Home() {
  return (
    <div className="space-y-12">
      <section className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-3xl font-bold mb-4 text-[#800020]">Останні новини</h2>
        <NewsCarousel />
        <Link
          href="/news"
          className="inline-block bg-[#800020] text-white px-4 py-2 rounded hover:bg-[#600010] transition-colors mt-4"
        >
          Більше новин
        </Link>
      </section>

      <section className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-3xl font-bold mb-4 text-[#800020]">Гороскоп на сьогодні</h2>
        <div className="relative w-full h-48 rounded-lg overflow-hidden mb-4">
          <img
            src="/placeholder.svg?height=200&width=800"
            alt="Гороскоп на сьогодні"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
            <h3 className="text-xl font-bold text-white">Дізнайтеся, що зірки приготували для вас сьогодні</h3>
          </div>
        </div>
        <Link
          href="/horoscope"
          className="inline-block bg-[#800020] text-white px-4 py-2 rounded hover:bg-[#600010] transition-colors"
        >
          Читати гороскоп
        </Link>
      </section>

      <section className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-3xl font-bold mb-4 text-[#800020]">Популярні програми</h2>
        <PopularShows />
      </section>

      <section className="bg-white shadow-md rounded-lg p-6">
        <h2 className="text-3xl font-bold mb-4 text-[#800020]">Ласкаво просимо на Шері ФМ</h2>
        <p className="mb-4 text-lg">
          Шері ФМ - це ваше джерело найкращої музики та цікавих програм. Ми прагнемо створити атмосферу, яка надихає,
          розважає та об'єднує наших слухачів.
        </p>
        <p className="text-lg">
          Наша місія - дарувати вам позитивні емоції кожного дня. Слухайте нас онлайн, в додатку або на радіохвилях, і
          нехай ваш день буде наповнений чудовою музикою!
        </p>
      </section>
    </div>
  )
}

