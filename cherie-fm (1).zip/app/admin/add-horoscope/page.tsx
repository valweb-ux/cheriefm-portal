"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"

const zodiacSigns = [
  "Овен",
  "Телець",
  "Близнюки",
  "Рак",
  "Лев",
  "Діва",
  "Терези",
  "Скорпіон",
  "Стрілець",
  "Козеріг",
  "Водолій",
  "Риби",
]

export default function AddHoroscopePage() {
  const [sign, setSign] = useState("")
  const [prediction, setPrediction] = useState("")
  const [date, setDate] = useState("")
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/horoscope", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ sign, prediction, date }),
    })
    if (response.ok) {
      router.push("/horoscope")
    } else {
      alert("Помилка при додаванні гороскопу")
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4 text-[#800020]">Додати гороскоп</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="sign" className="block text-lg font-medium text-gray-700">
            Знак зодіаку
          </label>
          <select
            id="sign"
            value={sign}
            onChange={(e) => setSign(e.target.value)}
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#800020] focus:ring-[#800020]"
          >
            <option value="">Оберіть знак зодіаку</option>
            {zodiacSigns.map((zodiacSign) => (
              <option key={zodiacSign} value={zodiacSign}>
                {zodiacSign}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="prediction" className="block text-lg font-medium text-gray-700">
            Передбачення
          </label>
          <textarea
            id="prediction"
            value={prediction}
            onChange={(e) => setPrediction(e.target.value)}
            required
            rows={5}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#800020] focus:ring-[#800020]"
          ></textarea>
        </div>
        <div>
          <label htmlFor="date" className="block text-lg font-medium text-gray-700">
            Дата
          </label>
          <input
            type="date"
            id="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#800020] focus:ring-[#800020]"
          />
        </div>
        <button
          type="submit"
          className="bg-[#800020] text-white px-4 py-2 rounded hover:bg-[#600010] transition-colors"
        >
          Додати гороскоп
        </button>
      </form>
    </div>
  )
}

