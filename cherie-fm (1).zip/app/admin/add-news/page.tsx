"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Switch } from "@/components/ui/switch"

export default function AddNewsPage() {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [inCarousel, setInCarousel] = useState(false)
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const response = await fetch("/api/news", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ title, content, imageUrl, inCarousel }),
    })
    if (response.ok) {
      router.push("/admin/news")
    } else {
      alert("Помилка при додаванні новини")
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4 text-[#800020]">Додати новину</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="title" className="block text-lg font-medium text-gray-700">
            Заголовок
          </label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            required
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#800020] focus:ring-[#800020]"
          />
        </div>
        <div>
          <label htmlFor="content" className="block text-lg font-medium text-gray-700">
            Зміст
          </label>
          <textarea
            id="content"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            required
            rows={5}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#800020] focus:ring-[#800020]"
          ></textarea>
        </div>
        <div>
          <label htmlFor="imageUrl" className="block text-lg font-medium text-gray-700">
            URL зображення
          </label>
          <input
            type="url"
            id="imageUrl"
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-[#800020] focus:ring-[#800020]"
          />
        </div>
        <div className="flex items-center">
          <Switch id="inCarousel" checked={inCarousel} onCheckedChange={setInCarousel} />
          <label htmlFor="inCarousel" className="ml-2 text-lg font-medium text-gray-700">
            Додати в карусель
          </label>
        </div>
        <button
          type="submit"
          className="bg-[#800020] text-white px-4 py-2 rounded hover:bg-[#600010] transition-colors"
        >
          Додати новину
        </button>
      </form>
    </div>
  )
}

