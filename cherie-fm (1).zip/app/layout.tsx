import "./globals.css"
import { Inter } from "next/font/google"
import TopBar from "./components/TopBar"
import Header from "./components/Header"
import Footer from "./components/Footer"
import type React from "react"

const inter = Inter({ subsets: ["latin"] })

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html>
      <head>
        <meta name="theme-color" content="#D53F8C" />
        <link rel="canonical" href="https://cheriefm.online" />
      </head>
      <body className={inter.className}>
        <div className="flex flex-col min-h-screen">
          <TopBar />
          <Header />
          <main className="flex-grow container mx-auto px-4 py-8">{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  )
}

