import { useLanguage } from "../components/LanguageProvider"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function ContactPage() {
  const { language } = useLanguage()

  return (
    <>
      <h1>Контакти</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card>
          <CardContent className="p-6 space-y-6">
            <h2>Наші контакти</h2>
            <ul className="space-y-4">
              <li>
                <strong>Адреса:</strong> вул. Радіо, 1, м. Київ, 01001
              </li>
              <li>
                <strong>Телефон:</strong> +38 (044) 123-45-67
              </li>
              <li>
                <strong>Email:</strong> cheriefmukraine@gmail.com
              </li>
            </ul>
            <h3>Години роботи</h3>
            <p>Понеділок - П'ятниця: 9:00 - 18:00</p>
            <p>Субота - Неділя: 10:00 - 16:00</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <h2>Напишіть нам</h2>
            <form className="space-y-4">
              <div>
                <label htmlFor="name" className="block mb-2 font-medium">
                  Ім'я
                </label>
                <Input type="text" id="name" name="name" required />
              </div>
              <div>
                <label htmlFor="email" className="block mb-2 font-medium">
                  Email
                </label>
                <Input type="email" id="email" name="email" required />
              </div>
              <div>
                <label htmlFor="message" className="block mb-2 font-medium">
                  Повідомлення
                </label>
                <Textarea id="message" name="message" rows={4} required />
              </div>
              <Button type="submit" className="w-full bg-pink-600 hover:bg-pink-700">
                Надіслати
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </>
  )
}

