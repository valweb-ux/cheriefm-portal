import { useLanguage } from "../components/LanguageProvider"

export default function AdvertisingPage() {
  const { language } = useLanguage()

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Реклама</h1>
      <div className="space-y-6">
        <p>
          Шері ФМ пропонує ефективні рекламні можливості для вашого бізнесу. Наша аудиторія - це активні та
          платоспроможні слухачі, які цінують якісний контент та довіряють нашій радіостанції.
        </p>
        <h2 className="text-2xl font-semibold mt-6 mb-4">Наші рекламні послуги включають:</h2>
        <ul className="list-disc list-inside space-y-2">
          <li>Аудіо-ролики в ефірі</li>
          <li>Спонсорство програм</li>
          <li>Інтеграція бренду в контент</li>
          <li>Банерна реклама на сайті</li>
          <li>Реклама в подкастах</li>
        </ul>
        <p>
          Ми пропонуємо індивідуальний підхід до кожного клієнта та допоможемо розробити ефективну рекламну кампанію,
          яка відповідає вашим цілям та бюджету.
        </p>
        <p>
          Для отримання детальної інформації про наші рекламні можливості на сайті cheriefm.online та розцінки, будь
          ласка, зв'яжіться з нашим відділом реклами:
        </p>
        <ul className="mt-4">
          <li>
            <strong>Телефон:</strong> +38 (044) 987-65-43
          </li>
          <li>
            <strong>Email:</strong> cheriefmukraine@gmail.com
          </li>
        </ul>
      </div>
    </div>
  )
}

