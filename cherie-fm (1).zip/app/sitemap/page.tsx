import { useLanguage } from "../components/LanguageProvider"
import Link from "next/link"

export default function SitemapPage() {
  const { language } = useLanguage()

  const sitemapLinks = [
    { href: "/", label: "Головна" },
    { href: "/news", label: "Новини" },
    { href: "/programs", label: "Програми" },
    { href: "/about", label: "Про радіо" },
    { href: "/presenters", label: "Ведучі" },
    { href: "/contact", label: "Контакти" },
    { href: "/advertising", label: "Реклама" },
    { href: "/legal", label: "Правова інформація" },
    { href: "/donate", label: "Підтримати" },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Мапа сайту</h1>
      <ul className="space-y-4">
        {sitemapLinks.map((link, index) => (
          <li key={index}>
            <Link href={link.href} className="text-pink-600 hover:text-pink-800 transition-colors">
              {link.label}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  )
}

