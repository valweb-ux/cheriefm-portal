import Image from "next/image"

export default function LesiaNikitukRomancePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">
        Як військовий підкорив Лесю Нікітюк: наречений телеведучої зізнався, що йому це вдалося тільки з 30 спроби
      </h1>
      <div className="relative w-full h-[400px] mb-4">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lesia-nikituk-4NxTBxxkR4zrHrxNxc4NtDxTxhBG3Hy.jpg"
          alt="Леся Нікітюк з нареченим"
          fill
          className="object-cover rounded-lg"
          sizes="100vw"
          priority
        />
      </div>
      <p className="mb-4">
        Відома українська телеведуча Леся Нікітюк нещодавно поділилася зворушливою історією про те, як її наречений,
        військовий ЗСУ, завоював її серце. Виявляється, що шлях до серця Лесі був не таким вже й легким.
      </p>
      <p className="mb-4">
        За словами нареченого Лесі, йому знадобилося аж 30 спроб, щоб нарешті привернути увагу телеведучої. "Я не
        здавався, бо знав, що Леся - особлива. Кожна невдала спроба лише додавала мені рішучості", - розповів він.
      </p>
      <p>
        Леся, в свою чергу, зізналася, що саме наполегливість та щирість її обранця зрештою підкорили її серце. "Він
        показав мені, що справжнє кохання варте боротьби. Я щаслива, що він не здався", - поділилася телеведуча.
      </p>
    </div>
  )
}

