import Image from "next/image"

export default function BeyonceGrammyPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Греммі 2025: Бейонсе забрала головну нагороду</h1>
      <div className="relative w-full h-[400px] mb-4">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/beyonce-grammy-2025-nGxHCxhDXWxhzDxhzTzTHJTxhBG3Hy.jpg"
          alt="Бейонсе на Греммі 2025"
          fill
          className="object-cover rounded-lg"
          sizes="100vw"
          priority
        />
      </div>
      <p className="mb-4">
        Бейонсе знову підтвердила свій статус королеви музичної індустрії, вигравши головну нагороду на церемонії Греммі
        2025. Її альбом "Renaissance" був визнаний "Альбомом року", що стало її четвертою перемогою в цій престижній
        категорії.
      </p>
      <p className="mb-4">
        Під час своєї емоційної промови Бейонсе подякувала своїм фанатам, родині та команді за підтримку. "Ця нагорода -
        не лише моя перемога, але й перемога всіх, хто вірить у силу музики", - сказала співачка.
      </p>
      <p>
        Окрім головної нагороди, Бейонсе також отримала нагороди в категоріях "Найкраще R&B виконання" та "Найкраща
        танцювальна/електронна музика". Ця перемога зміцнила її позицію як найбільш нагородженої виконавиці в історії
        Греммі.
      </p>
    </div>
  )
}

