import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export default async function NewsPage() {
  const news = await prisma.news.findMany({
    orderBy: {
      createdAt: "desc",
    },
  })

  return (
    <>
      <h1 className="text-3xl font-bold mb-8 text-[#800020]">Новини</h1>
      {news.map((item) => (
        <Card key={item.id} className="mb-6">
          <CardContent className="p-6">
            <Link href={`/news/${item.id}`} className="text-2xl font-semibold mb-2 text-[#800020] hover:text-[#600010]">
              {item.title}
            </Link>
            <p className="text-gray-600 mb-4">{new Date(item.createdAt).toLocaleDateString("uk-UA")}</p>
            <p className="text-lg leading-relaxed">{item.content.substring(0, 200)}...</p>
          </CardContent>
        </Card>
      ))}
    </>
  )
}

