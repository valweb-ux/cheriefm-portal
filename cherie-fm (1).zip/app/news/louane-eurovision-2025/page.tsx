import Image from "next/image"

export default function LouaneEurovisionPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-4">Луан представлятиме Францію на Євробаченні 2025</h1>
      <div className="relative w-full h-[400px] mb-4">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/louane-eurovision-2025-wSMRfxXkR4zrHrxNxc4NtDxTxhBG3Hy.jpg"
          alt="Луан на Євробаченні 2025"
          fill
          className="object-cover rounded-lg"
          sizes="100vw"
          priority
        />
      </div>
      <p className="mb-4">
        Французька співачка Луан була обрана представляти Францію на конкурсі Євробачення 2025. Це рішення було
        оголошено сьогодні вранці французьким телеканалом France 2.
      </p>
      <p className="mb-4">
        Луан, відома своїм потужним голосом та емоційними виступами, висловила своє захоплення та готовність
        представляти свою країну на міжнародній сцені. "Це велика честь для мене. Я докладу всіх зусиль, щоб гідно
        представити Францію", - сказала співачка.
      </p>
      <p>
        Пісня, з якою Луан виступатиме на Євробаченні, буде представлена публіці в найближчі місяці. Фанати з
        нетерпінням чекають на цю прем'єру та вірять у успіх своєї улюбленої виконавиці на конкурсі.
      </p>
    </div>
  )
}

