import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function POST(request: Request) {
  try {
    const { sign, prediction, date } = await request.json()
    const horoscope = await prisma.horoscope.create({
      data: {
        sign,
        prediction,
        date,
      },
    })
    return NextResponse.json(horoscope)
  } catch (error) {
    return NextResponse.json({ error: "Помилка при додаванні гороскопу" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const horoscopes = await prisma.horoscope.findMany({
      where: {
        date: new Date(),
      },
    })
    return NextResponse.json(horoscopes)
  } catch (error) {
    return NextResponse.json({ error: "Помилка при отриманні гороскопів" }, { status: 500 })
  }
}

