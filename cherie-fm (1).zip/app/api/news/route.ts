import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function POST(request: Request) {
  try {
    const { title, content, imageUrl, inCarousel } = await request.json()
    const news = await prisma.news.create({
      data: {
        title,
        content,
        imageUrl,
        inCarousel,
      },
    })
    return NextResponse.json(news)
  } catch (error) {
    return NextResponse.json({ error: "Помилка при додаванні новини" }, { status: 500 })
  }
}

export async function GET() {
  try {
    const news = await prisma.news.findMany({
      orderBy: {
        createdAt: "desc",
      },
    })
    return NextResponse.json(news)
  } catch (error) {
    return NextResponse.json({ error: "Помилка при отриманні новин" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const { id, title, content, imageUrl, inCarousel } = await request.json()
    const updatedNews = await prisma.news.update({
      where: { id },
      data: {
        title,
        content,
        imageUrl,
        inCarousel,
      },
    })
    return NextResponse.json(updatedNews)
  } catch (error) {
    return NextResponse.json({ error: "Помилка при оновленні новини" }, { status: 500 })
  }
}

