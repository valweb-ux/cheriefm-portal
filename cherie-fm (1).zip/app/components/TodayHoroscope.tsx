import Link from "next/link"
import Image from "next/image"

export default function TodayHoroscope() {
  return (
    <section className="mb-12">
      <div className="relative w-full h-[200px] mb-4 overflow-hidden rounded-lg">
        <Image src="/placeholder.svg?height=200&width=800" alt="Гороскоп на сьогодні" fill className="object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <h2 className="text-2xl font-bold text-white">Дізнайтеся, що зірки приготували для вас сьогодні</h2>
        </div>
      </div>
      <Link
        href="/horoscope"
        className="inline-block bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-700 transition-colors"
      >
        Гороскоп на сьогодні
      </Link>
    </section>
  )
}

