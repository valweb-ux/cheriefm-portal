import Link from "next/link"
import Image from "next/image"

interface AdBannerProps {
  src: string
  alt: string
  link: string
}

export default function AdBanner({ src, alt, link }: AdBannerProps) {
  return (
    <Link href={link} target="_blank" rel="noopener noreferrer" className="block">
      <Image src={src || "/placeholder.svg"} alt={alt} width={800} height={200} className="rounded-lg" />
    </Link>
  )
}

