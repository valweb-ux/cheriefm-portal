import Image from "next/image"
import Link from "next/link"
import { useLanguage } from "./LanguageProvider"
import AdBanner from "./AdBanner"

export default function FeaturedNews() {
  const { language } = useLanguage()

  const mainNews = {
    title:
      language === "uk"
        ? '"Бріджит Джонс 4": Г\'ю Грант у Парижі вражає досконалою французькою'
        : '"Bridget Jones 4": Hugh Grant in Paris, surprises with perfect French',
    image:
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/MEITU_20250131_113303220.jpg-SvC7CoBrotbWIkCr0zjV7uSaTAecGS.jpeg",
    link: "/news/1",
  }

  const sideNews = [
    {
      title:
        language === "uk"
          ? "Шері ФМ Україна запрошує на концерт Джеймса Бланта"
          : "Chérie FM Ukraine invites you to James Blunt's concert",
      description:
        language === "uk"
          ? "Почуйте дві пісні Джеймса Бланта і виграйте квитки на концерт у Києві!"
          : "Hear two James Blunt songs and win tickets to his concert in Kyiv!",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/james-blunt-concert-nGxHCxhDXWxhzDxhzTzTHJTxhBG3Hy.jpg",
      link: "/news/2",
    },
    {
      title:
        language === "uk" ? 'Хіт дня 17-20: "Я змінився" від Кенджі' : 'Hit of the day 17-20: "J\'ai Change" by Kendji',
      description:
        language === "uk"
          ? "Нова пісня, яка захоплює серця слухачів"
          : "The new song that's capturing listeners' hearts",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/kendji-girac-performing-wSMRfxXkR4zrHrxNxc4NtDxTxhBG3Hy.jpg",
      link: "/news/3",
    },
    {
      title:
        language === "uk"
          ? "Новий альбом Тіни Кароль б'є рекорди прослуховувань"
          : "Tina Karol's new album breaks streaming records",
      description:
        language === "uk"
          ? "Довгоочікуваний альбом встановив новий рекорд на стрімінгових платформах"
          : "The long-awaited album has set a new record on streaming platforms",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/tina-karol-new-album-4NxTBxxkR4zrHrxNxc4NtDxTxhBG3Hy.jpg",
      link: "/news/4",
    },
  ]

  return (
    <section className="mb-12">
      <h2 className="text-2xl font-bold mb-6 text-pink-800">{language === "uk" ? "Новини" : "News"}</h2>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Main News Item */}
        <div className="lg:col-span-1">
          <Link href={mainNews.link} className="group block relative aspect-[16/9] overflow-hidden rounded-lg h-full">
            <Image
              src={mainNews.image || "/placeholder.svg"}
              alt={mainNews.title}
              fill
              className="object-cover transition-transform duration-500 group-hover:scale-105"
              priority
            />
            <div className="absolute inset-x-0 bottom-0 h-[40%] bg-gradient-to-t from-black/90 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <h3 className="text-xl md:text-2xl font-bold text-white">{mainNews.title}</h3>
            </div>
          </Link>
        </div>

        {/* Side News Items */}
        <div className="lg:col-span-1 flex flex-col justify-between h-full">
          {sideNews.map((news, index) => (
            <Link
              key={index}
              href={news.link}
              className="group block relative aspect-[16/9] overflow-hidden rounded-lg mb-4 last:mb-0"
            >
              <Image
                src={news.image || "/placeholder.svg"}
                alt={news.title}
                fill
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
              <div className="absolute inset-x-0 bottom-0 h-[50%] bg-gradient-to-t from-black/90 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <h3 className="text-base md:text-lg font-bold text-white mb-1">{news.title}</h3>
                <p className="text-sm text-white/80 line-clamp-2">{news.description}</p>
              </div>
            </Link>
          ))}
          <Link
            href="/news"
            className="text-pink-600 hover:text-pink-800 transition-colors duration-300 font-semibold text-right mt-2"
          >
            {language === "uk" ? "Більше новин" : "More news"}
          </Link>
        </div>
      </div>

      {/* Ad Banner */}
      <div className="mt-8">
        <AdBanner
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cherie-fm-banner-ad-example-4NxTBxxkR4zrHrxNxc4NtDxTxhBG3Hy.jpg"
          alt="Шері ФМ Україна - Відчуй гарну музику"
          link="https://cheriefm.ua/promo"
        />
      </div>
    </section>
  )
}

