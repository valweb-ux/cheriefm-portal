"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import Player from "./Player"
import { useMediaQuery } from "@/hooks/useMediaQuery"

const navItems = [
  { href: "/", label: "Головна" },
  { href: "/news", label: "Новини" },
  { href: "/horoscope", label: "Гороскоп" },
  { href: "/programs", label: "Програми" },
]

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const isMobile = useMediaQuery("(max-width: 768px)")

  return (
    <header className="bg-[#800020] text-white shadow-md">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex flex-col">
            <span className="text-2xl font-extrabold">Шері ФМ</span>
            <span className="text-sm text-white/80 font-light italic">Відчуй гарну музику</span>
          </Link>
          <Player compact={isMobile} />
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-white hover:text-pink-200 transition-colors duration-300"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/donate"
              className="bg-yellow-500 text-black px-4 py-2 rounded hover:bg-yellow-400 transition-colors duration-300"
            >
              Підтримати
            </Link>
          </nav>
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-text">
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      {isMenuOpen && (
        <div className="md:hidden bg-[#800020] py-4">
          <nav className="container mx-auto px-4 flex flex-col space-y-4">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="text-white hover:text-pink-200 transition-colors duration-300"
              >
                {item.label}
              </Link>
            ))}
            <Link
              href="/donate"
              className="bg-yellow-500 text-black px-4 py-2 rounded hover:bg-yellow-400 transition-colors duration-300 inline-block text-center"
            >
              Підтримати
            </Link>
          </nav>
        </div>
      )}
    </header>
  )
}

