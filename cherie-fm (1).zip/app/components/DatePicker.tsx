"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"

interface DatePickerProps {
  onDateChange: (date: Date | undefined) => void
}

export function DatePicker({ onDateChange }: DatePickerProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())

  const handleDateChange = (newDate: Date | undefined) => {
    setDate(newDate)
    onDateChange(newDate)
  }

  return (
    <Calendar
      mode="single"
      selected={date}
      onSelect={handleDateChange}
      className="rounded-md border"
      fromDate={new Date(2025, 1, 1)} // February 1, 2025
    />
  )
}

