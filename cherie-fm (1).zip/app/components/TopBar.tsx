import Link from "next/link"
import { Facebook, Youtube, Search } from "lucide-react"
import { useLanguage } from "./LanguageProvider"
import { Button } from "@/components/ui/button"

export default function TopBar() {
  const { language, setLanguage } = useLanguage()

  // Removed getLink function

  return (
    <div className="bg-pink-600 text-white py-2">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <a
            href="https://www.facebook.com/cherieukraine"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white hover:opacity-80 transition-opacity"
          >
            <Facebook size={20} />
          </a>
          <a
            href="https://www.youtube.com/@cheriefm.ukraine"
            target="_blank"
            rel="noopener noreferrer"
            className="text-white hover:opacity-80 transition-opacity"
          >
            <Youtube size={20} />
          </a>
        </div>
        <div className="flex items-center space-x-6 text-sm">
          <Link href="/sitemap" className="hidden md:inline-block text-white hover:opacity-80 transition-opacity">
            {language === "uk" ? "Мапа сайту" : "Site Map"}
          </Link>
          <Link href="/contact" className="hidden md:inline-block text-white hover:opacity-80 transition-opacity">
            {language === "uk" ? "Контакти" : "Contact"}
          </Link>
          <Button
            asChild
            variant="secondary"
            size="sm"
            className="md:hidden bg-yellow-500 text-black hover:bg-yellow-400 px-2 py-1 text-xs"
          >
            <Link href="/donate">{language === "uk" ? "Підтримати" : language === "en" ? "Support" : "Soutenir"}</Link>
          </Button>
          <button className="text-white hover:opacity-80 transition-opacity">
            <Search size={20} />
          </button>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-transparent border-none text-white hover:opacity-80 transition-opacity appearance-none cursor-pointer"
            style={{
              color: "white",
              backgroundImage:
                "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='white' viewBox='0 0 24 24'%3E%3Cpath d='M7 10l5 5 5-5z'/%3E%3C/svg%3E\")",
              backgroundRepeat: "no-repeat",
              backgroundPosition: "right 0.5rem center",
              backgroundSize: "1.5em 1.5em",
              paddingRight: "2rem",
            }}
          >
            <option value="uk" style={{ color: "black" }}>
              українська
            </option>
            <option value="fr" style={{ color: "black" }}>
              Français
            </option>
            <option value="en" style={{ color: "black" }}>
              English
            </option>
          </select>
        </div>
      </div>
    </div>
  )
}

