import type React from "react"

interface PageLayoutProps {
  children: React.ReactNode
  title: string
}

export default function PageLayout({ children, title }: PageLayoutProps) {
  return (
    <div className="container">
      <h1>{title}</h1>
      <div className="card">{children}</div>
    </div>
  )
}

