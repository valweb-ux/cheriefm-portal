import Link from "next/link"
import { Facebook, Youtube } from "lucide-react"

const footerLinks = [
  { href: "/about", label: "Про радіо" },
  { href: "/sitemap", label: "Мапа сайту" },
  { href: "/presenters", label: "Ведучі" },
  { href: "/programs", label: "Програми" },
  { href: "/contact", label: "Контакти" },
  { href: "/advertising", label: "Реклама" },
  { href: "/legal", label: "Правова інформація" },
]

const socialLinks = [
  { icon: Facebook, href: "https://www.facebook.com/cherieukraine" },
  { icon: Youtube, href: "https://www.youtube.com/@cheriefm.ukraine" },
]

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-[#800020] text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h2 className="text-2xl font-bold mb-4">Шері ФМ Україна</h2>
            <img src="/logo.png" alt="Шері ФМ Україна" className="w-32 h-auto" />
          </div>
          <nav className="grid grid-cols-2 gap-4">
            {footerLinks.map((link) => (
              <Link key={link.href} href={link.href} className="hover:text-pink-200 transition-colors duration-300">
                {link.label}
              </Link>
            ))}
          </nav>
          <div>
            <h3 className="text-xl font-semibold mb-4">Слідкуйте за нами</h3>
            <div className="flex space-x-4">
              {socialLinks.map((link, index) => (
                <a
                  key={index}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-white hover:text-pink-200 transition-colors duration-300"
                >
                  <link.icon size={24} />
                </a>
              ))}
            </div>
          </div>
        </div>
        <div className="text-center text-sm text-white/60 mt-8">
          © {currentYear} Шері ФМ Україна |{" "}
          <a href="https://cheriefm.online" className="hover:text-pink-200">
            cheriefm.online
          </a>
        </div>
      </div>
    </footer>
  )
}

