"use client"

import { createContext, useContext, useState, useEffect } from "react"
import type React from "react"

const LanguageContext = createContext<{
  language: string
  setLanguage: (lang: string) => void
}>({
  language: "uk",
  setLanguage: () => {},
})

export const useLanguage = () => useContext(LanguageContext)

export default function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState("uk")

  useEffect(() => {
    const userLanguage = navigator.language.split("-")[0]
    const initialLanguage = ["uk", "fr", "en"].includes(userLanguage) ? userLanguage : "uk"
    setLanguage(initialLanguage)
  }, [])

  const handleSetLanguage = (newLang: string) => {
    if (newLang !== language) {
      setLanguage(newLang)
    }
  }

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage }}>{children}</LanguageContext.Provider>
  )
}

