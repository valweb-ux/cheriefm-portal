"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface NewsItem {
  id: number
  title: string
  imageUrl: string
  inCarousel: boolean
}

export default function NewsCarousel() {
  const [news, setNews] = useState<NewsItem[]>([])
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    fetch("/api/news")
      .then((response) => response.json())
      .then((data) => {
        const carouselNews = data.filter((item: NewsItem) => item.inCarousel)
        setNews(carouselNews)
      })
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % news.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [news.length])

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % news.length)
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + news.length) % news.length)

  if (news.length === 0) return null

  return (
    <div className="relative w-full h-64 md:h-96 overflow-hidden rounded-lg">
      <div
        className="flex transition-transform duration-500 ease-in-out h-full"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {news.map((item) => (
          <Link key={item.id} href={`/news/${item.id}`} className="min-w-full h-full relative group">
            <Image
              src={item.imageUrl || "/placeholder.svg"}
              alt={item.title}
              fill
              className="object-cover"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent group-hover:from-black/80 transition-all duration-300" />
            <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6">
              <h3 className="text-lg md:text-xl font-bold text-white group-hover:text-primary transition-colors duration-300">
                {item.title}
              </h3>
            </div>
          </Link>
        ))}
      </div>
      <button
        onClick={prevSlide}
        className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 text-primary hover:bg-white hover:text-primary-dark p-2 rounded-full transition-colors duration-300"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 text-primary hover:bg-white hover:text-primary-dark p-2 rounded-full transition-colors duration-300"
      >
        <ChevronRight size={24} />
      </button>
    </div>
  )
}

