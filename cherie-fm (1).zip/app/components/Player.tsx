"use client"

import { useState } from "react"
import { Play, Pause, Volume2, VolumeX } from "lucide-react"

interface PlayerProps {
  compact?: boolean
}

export default function Player({ compact = false }: PlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [volume, setVolume] = useState(50)
  const [isMuted, setIsMuted] = useState(false)

  const togglePlay = () => setIsPlaying(!isPlaying)
  const toggleMute = () => setIsMuted(!isMuted)

  return (
    <div className="flex items-center justify-between text-white">
      <div className="flex items-center space-x-4">
        <button
          onClick={togglePlay}
          className="bg-[#FF4081] hover:bg-[#C51162] rounded-full p-2 transition-colors duration-300"
        >
          {isPlaying ? <Pause size={20} /> : <Play size={20} />}
        </button>
        {!compact && (
          <div className="text-sm hidden md:block">
            <p className="font-semibold">Зараз в ефірі</p>
            <p className="text-white/80">Lady Gaga - Shallow</p>
          </div>
        )}
      </div>
      <div className="flex items-center space-x-2">
        <button onClick={toggleMute} className="text-white hover:text-[#FF4081] transition-colors duration-300">
          {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
        </button>
        <input
          type="range"
          min="0"
          max="100"
          value={isMuted ? 0 : volume}
          onChange={(e) => {
            setVolume(Number(e.target.value))
            setIsMuted(false)
          }}
          className="w-24 accent-[#FF4081]"
        />
      </div>
    </div>
  )
}

