import Image from "next/image"
import Link from "next/link"

const shows = [
  {
    title: "Ранковий Драйв",
    host: "Анна Ковальчук",
    image: "/placeholder.svg?height=200&width=200",
    time: "Пн-Пт, 7:00 - 10:00",
  },
  {
    title: "Музичний Мікс",
    host: "Олег Петренко",
    image: "/placeholder.svg?height=200&width=200",
    time: "Пн-Пт, 12:00 - 15:00",
  },
  {
    title: "Вечірній Настрій",
    host: "Марія Шевченко",
    image: "/placeholder.svg?height=200&width=200",
    time: "Пн-Пт, 18:00 - 21:00",
  },
]

export default function PopularShows() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {shows.map((show, index) => (
        <Link
          key={index}
          href={`/programs/${show.title.toLowerCase().replace(/\s+/g, "-")}`}
          className="card hover:shadow-lg transition-shadow duration-300"
        >
          <div className="relative h-48">
            <Image src={show.image || "/placeholder.svg"} alt={show.title} fill className="object-cover" />
          </div>
          <div className="p-4">
            <h3 className="text-lg font-semibold mb-2">{show.title}</h3>
            <p className="text-text-light mb-1">Ведучий: {show.host}</p>
            <p className="text-text-light text-sm">{show.time}</p>
          </div>
        </Link>
      ))}
    </div>
  )
}

